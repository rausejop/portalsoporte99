<?php
  print("<html>\n");
	print("<title>Resultados</title>\n");
	print("<body>\n");
  print("<script language='JavaScript'>
  function NuevaConsulta()
  {
  	location.href='consulta.php';
  }
  function LanzaNuevo()
  {
  	location.href='nuevo.php';
  }
  </script>");
	print("<p align='left'><big><big><big><em><strong><font color='#000000'>Resulta</font><font 	color='#FF0000'>do</font><font color='#000000'> de la Consul</font><font color='#FF0000'>ta</font><font color='#000000'> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></strong></em></big></big></big><input src='../multico.jpg' name='I1' width='208' height='59' alt='Falta el logo' type='image'></p><div align='center'><center>\n");
  /* Muestra el registro si existe. Si no, un espacio */
  
  
  
  function campo($campo) {
    $separador="[VAC�O]";
    if ($campo) {
      	if ($campo ==".")
      		echo ("<td align=center>");
			else
				echo ("<td align=justify>");
      	echo ("$campo");
      echo ("</td>");
    }
    else
      echo ("<td align=center>$separador</td>");
  }


  /* A�ade una cl�usula AND al Select */
  function comprueba($campo) {
    global $$campo;
    $aux=$$campo;   /* La variable auxiliar es el meollo de la cuesti�n */
    if ($campo) return ("$campo like '%$aux%'"); /* 'campo' like 'contenido de campo' */ 
  }

		
  printf("Resultado de consulta para $REMOTE_ADDR " . " (".gethostbyaddr($REMOTE_ADDR).")"."<br>\n\n\n");

  /* Cargar los arrays de campos */
  $descriptor	= odbc_connect("SOPORTE","","");
  $query	= "select * from CAMPOS";
  $registro	= odbc_exec($descriptor, $query);
  $i=0;
  $CNom[$i]=""; /* CAMPOS.Campo */
  $CDesc[$i]="";/* CAMPOS.Descripci�n*/
  while (odbc_fetch_row($registro)) {
	$CNom[$i] = odbc_result($registro, 2); /* ($registro, "CAMPO") */
	$CDesc[$i] = odbc_result($registro, 3);/* ($registro, "DESCRIPCION") */
        $i++;
  }


  /* Ejecutar la consulta */
  $query	= "select * from PROBLEMAS";
  /* Creaci�n de la consulta */	
  $cont=0;
  for ($j=0; $j<count($CNom); $j++) {
	$aux=$$CNom[$j]; 	/* $aux = $producto, $problema, $solucion, $estado ... */
	if ($aux != "") {	/* Si uno de los campos est� vac�o pasamos al */
		$cont++;					/* siguiente y no lo incluimos en la consulta */
		if ($cont == 1) {
		  $query= $query . " where "; /* El resto de cl�usulas deber�an ser AND */
 		}
		else {
		  $query= $query . " and ";		/* Vamos a�adiendo los campos que interesan (no vac�os) a la consulta */   		}													
		$query= $query . comprueba($CNom[$j]);
	};
  }
  $query= $query . "ORDER BY ID";
//echo("Consulta SQL:   $query<br><br><br>\n\n\n");
print("<center><h3>Pulse en el c�digo del problema para editarlo</h3></center>\n");

  /* Ejecuto la consulta*/
  $registro	= odbc_exec($descriptor, $query);

  //echo("<form>\n");
  /* Cabecera de la tabla */
  echo ("<table border=1 width=100%>\n");
  echo("<tr>");
  for ($j=0; $j<count($CDesc); $j++) {
        echo("<th> $CDesc[$j]</th>");
  }
  echo("</tr>\n");

  /* Por cada registro */
  $fila = 0;
  while (odbc_fetch_row($registro))					 	/* Mientras recorremos los registros vamos creando */
  { 		   																		/* la p�gina HTML */	
		//echo($fila);
		for ($j=0; $j<count($CNom); $j++)					/* Generamos una variable con el nombre de cada campo de la */
		{																				/* tabla y guardamos su contenido en ella */
      $$CNom[$j] = odbc_result($registro, "$CNom[$j]");	/*$$CNom[0]=$ID, $CNom[0]="T9812..."*/
		}																									 	/*$$CNom[1]=$PRODUCTO, $CNom[1]="IP din�mica"*/
    echo("<tr align=justify valign=center>");
    echo ("<td align=justify>");
    $aux=$$CNom[0];
    echo("<form action = 'modifica.php' method = 'post'>");
//    echo ("<a href='modifica.php' Onclick={document.forms[$fila].submit();}>");
    printf("<input type='Submit' value=$aux>");
    printf("<input type='hidden' name='C�DIGO' value=$aux>");
//    echo ("<input type=text name='C�DIGO' style='border: medium none' value=$aux>");
    echo("</a></form>\n");
    for ($j=1; $j<count($CNom); $j++) {
      campo($$CNom[$j]); /* se dedica a generar el c�digo HTML adecuado */
    }
    echo("</tr>\n");
    $fila ++;
 }
  echo ("</table>\n");
//  echo("</form>\n");


  /* Cerrar conexi�n ODBC */
  odbc_close($descriptor);
  echo("<br><br><center><Input type=button value='Nueva Consulta' onClick=NuevaConsulta();> <input type='button' value='Nuevo' onClick=LanzaNuevo();> </center>");
  echo ("</body></html>");
  
  //phpinfo();
?>
