<?php

require("include/libbd.inc");
print("<html>\n");
print("<title>SOPORTE: Llamadas Telef�nicas</title>\n");
print("<body>\n");
/**************FUNCIONES***************
print("<script language='JavaScript'>
        function LanzaConsulta()
        { document.forms[0].action='resulta2.php';
          document.forms[0].submit();
        }
        </script>");
/***************************************/

print("<p align='left'><big><big><big><em><strong><font color='#000000'>LLamad</font><font color='#FF0000'>as</font><font color='#000000'> Entrant</font><font color='#FF0000'>es</font><font color='#000000'> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></strong></em></big></big></big><input src='../multico.jpg' name='I1' alt='Falta el logo' type='image'></p><div align='center'>\n<center>\n");

/*************** Cargar los arrays de campos de SOPORTE *******************************/
  $descriptor	= odbc_connect("SOPORTE","","");
  $query	= "select * from CAMPOS";
  $registro	= odbc_exec($descriptor, $query);
  $i=0;
  $CNom[$i]=""; /* CAMPOS.Campo */
  $CDesc[$i]="";/* CAMPOS.Descripci�n*/
  while (odbc_fetch_row($registro))
  {
		$CNom[$i] = odbc_result($registro, 2); /* ($registro, "CAMPO") */
		$CDesc[$i] = odbc_result($registro, 3);/* ($registro, "DESCRIPCION") */
    $i++;
  }
/**************************************************************************************/

  
/* Inicio del formulario */
printf("<form name='formularioAltas' method='post' action='tlf1.php'>\n");

/* Inicio de la tabla */
print("  <table border='0' width='100%' height='189'>\n"); 
print("  <tr>\n");

/***************************** Campos de fecha *************************************/
$cod=date("d-m-Y");
print("    <td align='left' valign='baseline'> <p>Fecha: </p></td>\n");
print("    <td align='left' valign='baseline'><input type='text' name='FINICIO' value = '$cod' size='22'></td>\n");
print("  </tr>\n");

print("  <tr>\n");



print("    <td width='15%' align='left' valign='baseline' height='26'><p>Empresa:</p>\n");
print("    </td>\n");
print("    <td width='35%' align='left' valign='baseline' height='26'><input type='text' name='EMPRESA' size='22' tabindex='1'></td>\n");

/* Comprobaci�n del campo T�CNICO */
							   		
  for ($i=0; $i < count($CNom); $i++) 
  {
    if ($CNom[$i]=="T�CNICO")
    {
			$Campo="<td>Para:</td><td align=left><select name='$CNom[$i]' size='1' tabindex='7'>";
		  $queryT�cnicos    = "select * from TECNICOS";
      $registroT�cnicos = odbc_exec($descriptor, $queryT�cnicos);

      while ( odbc_fetch_row($registroT�cnicos) )
      {
         $Campo = $Campo . "<OPTION>" . odbc_result($registroT�cnicos, 2);
      };
      $Campo = $Campo . "</SELECT></td>\n";
      printf("$Campo");	
    }
   }
		

print("  <tr>\n");
print("    <td width='15%' valign='middle' height='26' align='left'><p>Contacto:&nbsp;&nbsp; </p>\n");
print("    </td>\n");
print("    <td width='35%' valign='middle' height='26' align='left'><input type='text' name='CONTACTO' size='22' tabindex='2'></td>\n");

/* Comprobaci�n del campo PRIORIDAD */
	for ($i=0; $i < count($CNom); $i++) 
  {
		if ($CNom[$i]=="PRIORIDAD")
		{
    	  $Campo="<td>Acci�n:</td><td align=left><SELECT NAME='$CNom[$i]' size='1' tabindex='8'>";
      $queryEstados    = "select * from ESTADOS";
      $registroEstados = odbc_exec($descriptor, $queryEstados);

      while ( odbc_fetch_row($registroEstados) )
      {
                $Campo = $Campo . "<OPTION>" . odbc_result($registroEstados, 2);
      };
      $Campo = $Campo . "</SELECT></td>\n";
      printf("$Campo");	
		}
  } 

print("  </tr>\n");
print("  <tr>\n");
print("    <td width='15%' align='left' valign='middle' height='26'>Tel�fono:</td>\n");
print("    <td width='35%' align='left' valign='middle' height='26'><p><input type='text' name='TEL�FONO' size='22' tabindex='3'></p>\n");
print("  </tr>\n");
print("  <tr>\n");
print("    <td width='15%' align='left' valign='top' height='86'><p>Asunto: &nbsp;&nbsp;</p>\n");
print("    </td>\n");
print("    <td width='35%' align='left' valign='top' height='86'><textarea rows='4' name='PROBLEMA' cols='38' tabindex='5'></textarea></td>\n");
print("    </td>\n");
print("  </tr>\n");
print("</table>\n");

/* Botones de env�o */
printf("<tr><td><input type='Submit' name='CONSULTAR' value='Comprobar empresa'></td>
            <td><input type='Reset'></td></tr>\n");
print("</form>\n");
print("</center></div>\n");

/* Cerrar la base de datos*/
odbc_close($descriptor);

print("</body>\n");
print("</html>\n");
?>
