<?php

/* result.php								*/
/* Resultados de b�squeda por contenido		*/
/* (c) 1999 MULTICO							*/


/* Includes */
require("../include/libhtml.inc");

/* Carga del Array de campos */
/*
$basededatos="CONTSUPP";
$tabla="CONSTSUPP";
*/
$basededatos="CONTACTOS";
$tabla="contact1";
echo ("<html><body>");

$query  = "SELECT * FROM  $tabla where COMPANY like '%MULTI%'";
BD_Consulta_Formateada($basededatos, $query);

echo ("como mola</body></html>");

?>