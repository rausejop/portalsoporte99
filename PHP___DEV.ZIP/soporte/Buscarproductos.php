<?php

/* Buscarproductos.php */
/* Formulario que env�a la cadena $Palabras	*/
/* (c) 1999 MULTICO							*/


/* Includes */
require('../include/libhtml.inc');

$titulo="Consulta de productos";
$cadena = HTML_Logotipo($titulo);

$formulario = H_input('text', 'Palabras', '', '') . HTML_botones();


$cadena = $cadena . H_center(H_form("Formulario", post, "Resultadoproductos.php", $formulario));

HTML_html($titulo,$cadena);

?>