<?php

/* soporte.php								*/
/* Formulario que env�a la cadena $Palabras	*/
/* (c) 1999 MULTICO							*/


/* Includes */
require('../include/libhtml.inc');


$titulo="Consultar Incidencias";
$cadena = HTML_Logotipo($titulo);


$formulario = 
  "EMPRESA "  . H_input('text', 'Empresa', '', '')  . "<br>" . 
  "PASSWORD " . H_input('text', 'Password', '', '') . "<br>" . 
  HTML_botones();

$cadena = $cadena . H_center(H_form("Formulario", post, "ResultadoIncidencias.php", $formulario));

HTML_html($titulo,$cadena);

?>