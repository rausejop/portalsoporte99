<?php

/* P_resultados.php                    */
/* Muestra los resultados de la b�squeda de $Palabras  */
/* (c) 1999 MULTICO                    */

/* Includes */
require("../include/libhtml.inc");
require("../include/libinet.inc");

$titulo="Productos encontrados";
$cadena = HTML_Logotipo($titulo);

$busqueda="<center><h4>Expresi�n regular '$Palabras': </h4></center>\n";
$cadena = $cadena . $busqueda;

/* Carga del Array de campos */
$basededatos="PRECIOS";
$definicion="CAMPOS";
$tabla="Lista";

BD_Campos($basededatos, $definicion, &$CNom, &$CDesc);
$campos = array (2,3,4,5,6);
$opcion=1;
$condiciones=BD_GeneraCondiciones($CNom, $Palabras, "AND");
$query=BD_GeneraSelect($campos, $tabla, $condiciones, $CNom);

/* Para debug*/
/* $cadena=$cadena . $query; */

$cadena=$cadena . BD_Consulta($basededatos, $CNom, $CDesc, $query, $campos); 
  $cadena=H_table($cadena, 100, 1);
HTML_html($titulo,$cadena);

$mensaje= "Se ha realizado una consulta desde " . gethostbyaddr($REMOTE_ADDR) ." [". $REMOTE_ADDR."]" . " con el siguiente resultado:\n";

while (list($var, $value) = each($HTTP_POST_VARS)) {
  $mensaje= $mensaje . $var . " = " . $value . "\n";
};

$ok=inet_mail("rafael@multico.es", "Consulta de Productos", $mensaje);

?>
