<?php

/* Resultadoincidencias.php				*/
/* Muestra los resultados de la b�squeda de $Palabras	*/
/* (c) 1999 MULTICO					*/

/* Includes */
require("../include/libhtml.inc");

$titulo="Incidencias encontradas";
$cadena = HTML_Logotipo($titulo);

$busqueda="<center><h4>Expresi�n regular '$Palabras': </h4></center>\n";
$cadena = $cadena . $busqueda;

$Empresa=strtoupper($Empresa);

/* Sacamos empresa y c�digo */
   $basededatos="CONTACT1";
   $tabla="contact1";
   $CNom[0]="ACCOUNTNO";
   $CDesc[0]="Cuenta";
   $CNom[1]="COMPANY";
   $CDesc[1]="Empresa";
   $campos = array (0,1);
   $query  = "SELECT ACCOUNTNO, COMPANY FROM $tabla where COMPANY like '%$Empresa%'";
   $auxaccount = BD_Campon($basededatos, $query, 1);
   $auxempresa = BD_Campon($basededatos, $query, 2);

/* Comprobamos password */
   $basededatos="CONTSUPP";
   $tabla="contsuppact1";
   $CNom[0]="ACCOUNTNO";	$CDesc[0]="Cuenta";
   $CNom[1]="RECTYPE";		$CDesc[1]="Tipo de registro";
   $CNom[2]="CONTACT";		$CDesc[2]="Contacto";
   $CNom[3]="TITLE";		$CDesc[3]="T�tulo";
   $CNom[4]="CONTSUPREF";	$CDesc[4]="Contsupref";
   $campos = array (1,2,3,4,5);
/*   $query  = "SELECT ACCOUNTNO, RECTYPE, CONTACT, TITLE, CONTSUPREF"
            ." FROM $tabla where ACCOUNTNO like '$auxaccount'"
            . " and CONTACT like 'Internet Address'";
*/

   $query  = "SELECT ACCOUNTNO, RECTYPE, CONTACT, TITLE, CONTSUPREF"
            ." FROM $tabla where ACCOUNTNO like '$auxaccount'"
            . " and CONTACT like 'NIF'";





  /*   $cadena = $cadena . BD_Consulta($basededatos, $CNom, $CDesc, $query, $campos); */
   $auxpassword = BD_Campon($basededatos, $query, 5);

/* Password err�neo */
   if ( ($Password != $auxpassword) || ($auxempresa=='') || ($auxpassword==''))
   {
     if ($auxempresa=='')
       $cadena= $cadena . "Empresa no encontrada. Compruebe que se ha tecleado en may�sculas y sin acentos";
     else   
       { 
/*         $auxempresa = convert_cyr_string($auxempresa, "i", "w"); */
         if ($auxpassword=='')
             $cadena= $cadena . "Empresa: $auxempresa<br>No se ha dado de alta el NIF en la base de datos.";  
         else  
             /* $cadena= $cadena . "Empresa: $auxempresa<br>Password err�neo. El correcto es: " .$auxpassword; */
/*             $cadena= $cadena . "Empresa: $auxempresa<br>NIF err�neo. El correcto es: " .$auxpassword;  */
               $cadena= $cadena . "Empresa: $auxempresa<br>NIF err�neo. El correcto es: " .$auxpassword; 

       } 
   }
   else
   {
/* Password v�lido */

   /* Carga del Array de campos */
   $basededatos="SOPORTE";
   $definicion="CAMPOS";
   $tabla="PROBLEMAS";

   BD_Campos($basededatos, $definicion, &$CNom, &$CDesc); 
   $campos = array (1,2,3,4,5,6,7,8,9,10,11,12);
   $opcion=1;
   $Palabras= $auxempresa;
   $query=" SELECT * from $tabla where EMPRESA like '$auxempresa' ";
/*   $condiciones=BD_GeneraCondiciones($CNom, $Palabras, "ALL"); */
/*   $query= BD_GeneraSelect($campos, $tabla, $condiciones, $CNom); */
    
   /* Para debug */
/*   $cadena= $cadena . $query; */

/*   $cadena= $cadena . "Empresa: $auxempresa<br>Password: " .$auxpassword; */
/*   $cadena= $cadena . "Empresa: $auxempresa<br>NIF: " .$auxpassword; */



   $cadena=$cadena . BD_Consulta($basededatos, $CNom, $CDesc, $query, $campos); 
   $cadena=H_table($cadena, 100, 1);
   };


HTML_html($titulo,$cadena);
?>