<?
 print md5(uniqid("some magic string"));
 phpinfo();
?>