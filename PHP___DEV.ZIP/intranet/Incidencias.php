<?php

/* soporte.php								*/
/* Formulario que env�a la cadena $Palabras	*/
/* (c) 1999 MULTICO							*/


/* Includes */
require('../include/libhtml.inc');
require('../include/libmat.inc');

$titulo="Modificar Incidencias";
$cadena = HTML_Logotipo($titulo). "\n";


$formulario ="";

$formulario =$formulario .
H_tr(
      H_td(H_input('radio', 'Bool', 'CUSTOM' ,''))
     . H_td("Consulta compleja<br>\n" 
     . "Ej: T�CNICO " . HTML_tecnicos() . " PRIORIDAD " . HTML_prioridad(). "<br><br>\n")
     , '', '');

$formulario =$formulario .
H_tr(
      H_td(H_input('radio', 'Bool', 'ALL' ,''))
      . H_td("Buscar la cadena completa<br>\nEj: Advanced Server for SAA<br>\n")
     , '', '');


$formulario =$formulario .
H_tr(
      H_td(H_input('radio', 'Bool', 'OR' ,''))
      . H_td("Buscar alguna palabra<br>\nEj: printer impresora prt<br>\n")
     , '', '');


$formulario =$formulario .
H_tr(
      H_td(H_input('radio', 'Bool', 'AND', 'checked'))
      . H_td("Buscar todas las palabras en un mismo campo<br>\nEj: Remo Autosync<br>\n")
     , '', '');

$formulario = H_table($formulario, 100, 0)
              . H_input('text', 'Palabras', date("Ym"), '')
              . "\n" . HTML_botones();

$cadena = $cadena . H_center(H_form("Formulario", post, "ResultadoIncidencias.php", $formulario));

HTML_html($titulo,$cadena);

?>
