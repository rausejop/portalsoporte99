<?php

/* Resultadoincidencias.php				*/
/* Muestra los resultados de la b�squeda de $Palabras	*/
/* (c) 1999 MULTICO										*/

/* Includes */
require("../include/libhtml.inc");
require("../include/libmat.inc");

$titulo="Incidencias encontradas";
$cadena = HTML_Logotipo($titulo);

$busqueda="<h4>Expresi�n regular: $Palabras</h4>\n";
$cadena = $cadena . $busqueda;

/* Carga del Array de campos */
$basededatos="SOPORTE";
$definicion="CAMPOS";
$tabla="PROBLEMAS";

BD_Campos($basededatos, $definicion, &$CNom, &$CDesc); 
$campos = array (1,2,3,4,5,6,7,8,9,10,11,12);
$opcion=1;
if ($Bool=="CUSTOM")
{


 $query = "SELECT * FROM $tabla WHERE T�CNICO like '$T�CNICO' and PRIORIDAD like '$PRIORIDAD'";
 $condiciones=$query;

/*
$condiciones=BD_GeneraCondicionesAnidadas($CNom, $Palabras, 'OR');
$query = BD_GeneraSelect($campos, $tabla, $condiciones, $CNom);
*/

}
else
{
  $condiciones=BD_GeneraCondiciones($CNom, $Palabras, $Bool);
  $query = BD_GeneraSelect($campos, $tabla, $condiciones, $CNom);
};

/* Para debug */
$cadena = $cadena . $query . "<br>\n";  

$direccion= "Resultado de consulta para $REMOTE_ADDR " .
            " (" . gethostbyaddr($REMOTE_ADDR) . ")" . "<br><br>\n\n\n";
$cadena=$cadena . $direccion . BD_Consulta_Edit($basededatos, $CNom, $CDesc, $query, $campos, '../modifica.php');
$cadena=H_table($cadena, 100, 1);
HTML_html($titulo,$cadena);
?>