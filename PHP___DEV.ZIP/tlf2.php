<?php

require("include/libinet.inc");

print("<html>\n");
print("<title>SOPORTE: Llamadas entrantes</title>\n");

print("<body>\n");                                                    
print("<script language='JavaScript'> function NuevaConsulta(){ location.href='tlf.php'; } </script>");

print("<p align='left'><big><big><big><em><strong><font color='#000000'>Notificaci</font><font color='#FF0000'>�n</font><font color='#000000'> de LLamad</font><font color='#FF0000'>as &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></strong></em></big></big></big><input src='../multico.jpg' name='I1'  alt='Falta el logo' type='image'></p><div align='center'><center>\n");

 /* Cargar los arrays de campos */
  $descriptor  = odbc_connect("SOPORTE","","");
  $query  = "select * from TECNICOS where CODIGO like '%$T�CNICO%'";
  $registro  = odbc_exec($descriptor, $query);
  $email  = odbc_result($registro, 6);
  $mensaje= "Llamada recibida desde " . gethostbyaddr($REMOTE_ADDR) ." [". $REMOTE_ADDR."]\n\n" .
	    "Fecha    = " . $FINICIO	. "\n"	.
            "Empresa  = " . $EMPRESA	. "\n"	.
            "Contacto = " . $CONTACTO	. "\n"	.
	    "Tel�fono = "  .$TEL�FONO	. "\n"	.
	    "Acci�n   = "  .$PRIORIDAD	. "\n"	.
	    "Para     = "  .$T�CNICO	. "\n"	.
	    "Asunto   = "  .$PROBLEMA	. "\n"	.
            "\n\n\n\n";

  $ok=inet_mail($email, "Llamadas entrantes", $mensaje);
  if ($ok==1)
    echo ("Se ha enviado un email a $email con el contenido de la notificaci�n<br>");
  else
    echo ("No se ha podido enviar la notificaci�n. Por favor, revise la conexi�n a Internet desde \\\\SERVER<br>");

  echo("<br><br><center><Input type=button value='Nueva Llamada' onClick=NuevaConsulta();> </center>");
  //phpinfo();
  echo ("</body></html>");

?>
