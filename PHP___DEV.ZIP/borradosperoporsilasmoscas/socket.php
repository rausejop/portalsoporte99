<?php
$fp =fsockopen("100.100.100.100", 25, &$errno, &$errstr);
if(!$fp) {
        echo "$errstr ($errno)<br>\n";
} else {
        fputs($fp,"GET / HTTP/1.0\n\n");
        while(!feof($fp)) {
                echo fgets($fp,128);
        }
        fclose($fp);
}
?>