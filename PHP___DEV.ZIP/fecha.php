<?php
print("<html>\n");
print("<title>Generaci�n de fecha</title>\n");
print("<body>\n");
echo date( "Ymd");
printf("$hoy");
phpinfo();
print("</body>\n");
print("</html>\n");
//phpinfo();
?>
