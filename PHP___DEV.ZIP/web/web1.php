<?php
	/* Include */
	require( "shared.inc");

	/* Cabecera */ 
	commonHeader("P�gina principal");

	/* Cuerpo */
	echo("Prueba de librer�as compartidas");

	/* Pie */
	commonFooter();
?>