<?php

require("include/libinet.inc");

print("<html>\n");
print("<title>Actualizaci�n de la base de datos</title>\n");

print("<body>\n");                                                    
print("<script language='JavaScript'> function NuevaConsulta(){ location.href='consulta.php'; } </script>");

print("<p align='left'><big><big><big><em><strong><font color='#000000'>Actualizaci</font><font color='#FF0000'>�n</font><font color='#000000'> de la Ba</font><font color='#FF0000'>se de </font><font color='#000000'>Dat</font><font color='#FF0000'>os &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></strong></em></big></big></big><input src='../multico.jpg' name='I1'  alt='Falta el logo' type='image'></p><div align='center'><center>\n");

 /* Cargar los arrays de campos */
  $descriptor  = odbc_connect("SOPORTE","","");
  $query  = "select * from CAMPOS";
  $registro  = odbc_exec($descriptor, $query);
  $i=0;
  $CNom[$i]=""; /* CAMPOS.Campo */
  $CDesc[$i]="";/* CAMPOS.Descripci�n*/
  while (odbc_fetch_row($registro)) {
  $CNom[$i] = odbc_result($registro, 2); /* ($registro, "CAMPO") */
  $CDesc[$i] = odbc_result($registro, 3);/* ($registro, "DESCRIPCION") */
        $i++;
  }
  
  /* if ($ULTIMO == '') */
    $ULTIMO = date("d-m-Y");

   /* Ejecutar la consulta */
  $query  = "update PROBLEMAS set ";
  
  for ($j=0; $j<count($CNom); $j++)
  {
    $aux1=$CNom[$j]; 
    $aux2=$$CNom[$j];
    if ($aux2 == "") $aux2=".";                                                                                                                                         
    $query= $query  ."$aux1"." = "."'$aux2'";  
    if ($j!=count($CNom)-1)
      $query= $query . " , ";            /* Ponemos una coma si no es el �ltimo campo*/
  }
  $id = $$CNom[0];
  $query= $query . " where $CNom[0] = '$id'";
  print("Consulta SQL:   $query<br><br><br>\n\n\n");
  $registro  = odbc_exec($descriptor, $query);
  echo ("<h2>El registro se ha actualizado con �xito en la base de datos</h2>");

  $mensaje= "Se ha actualizado la incidencia\nhttp://100.100.100.1/intranet/Resultadoincidencias.php?Palabras=$ID\n" .
            "desde " . gethostbyaddr($REMOTE_ADDR) ." [". $REMOTE_ADDR."]\n\n" .
	    "EMPRESA  = " . $EMPRESA   . "\n"	.
            "ESTADO   = " . $PRIORIDAD . "\n"	.
            "PRODUCTO = " . $PRODUCTO  . "\n"	.
	    "PROBLEMA = "  .$PROBLEMA		.
            "\n\n\n\n";
$mensaje= $mensaje .
"/******************/\n" . 
"/* DETALLES */\n" .
"/******************/\n\n\n";


  while (list($var, $value) = each($HTTP_POST_VARS)) {
    $mensaje= $mensaje . $var . " = " . $value . "\n";
  };

  echo("<br><br><center><Input type=button value='Nueva Consulta' onClick=NuevaConsulta();> </center>");
  //phpinfo();
  echo ("</body></html>");
  $ok=inet_mail("incidencias@multico.es", "Modificaci�n de Incidencias", $mensaje);
  if ($ok==1)
    echo ("Se ha enviado un email a incidencias@multico.es con el contenido de la actualizaci�n<br>");
  else
    echo ("Se ha modificado la incidencia pero no se ha podido enviar por e-mail. Por favor, revise la conexi�n a Internet desde \\\\SERVER<br>");
?>
