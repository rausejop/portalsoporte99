<?php
$hoy=date("Ymd");
$descriptor	= odbc_connect("SOPORTE","","");
$queryC�d	= "select ID from PROBLEMAS";
$registroC�d	= odbc_exec($descriptor, $queryC�d);
while (odbc_fetch_row($registroC�d)) 
{
	$id = odbc_result($registroC�d, 1); /* En id tenemos el �ltimo registro */
}
$long = strlen($id);
$inicio = substr($id, 0, $long - 2);
$fin = substr($id, $long - 2);
if ($inicio != $hoy)
{
	$fin = "1";
	$inicio = $hoy;
}
else
	$fin=$fin+1;
	
if  ($fin<10) 
  $C�DIGO= $inicio."0". $fin;
else
  $C�DIGO= $inicio.$fin;

$insertarNuevo = "insert into PROBLEMAS (ID) values ('$C�DIGO')"; /* Creamos un nuevo registro en la base de datos*/
$registro2	= odbc_exec($descriptor, $insertarNuevo);
print("<html>\n");
print("<center>\n");
print("<p><font face='Bookman Old Style' color='#FF0000'><em><big><big>Se ha creado un nuevo registro en la base de datos</big></big></em></font></p>\n");
print("Pulse para editar los datos de esta incidencia:<br><br>\n");
print("<form action = 'alta.php' method = 'post'>\n");
print("\t<input type=hidden  name='C�DIGO' value=$C�DIGO>");
print("\t<center><input type=button style='border: medium outset rgb(0,128,128)' value=$C�DIGO></center>\n");
print("Empresa: <input type='text' name='EMPRESA' value='Por actualizar' size='22'>");
print("<Input type=submit value='Enviar';>\n");
print("</form>\n");
print("</center>\n");
print("</html>");
odbc_close($descriptor);
?>

