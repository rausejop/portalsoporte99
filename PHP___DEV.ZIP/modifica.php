<?php
print("<html>\n");
print("<title>Modificaci�n de Incidencias</title>\n");
print("<body>\n");
print("<p align='left'><big><big><big><em><strong><font color='#000000'>Modificaci</font><font color='#FF0000'>�n</font><font color='#000000'> de Incidenci</font><font color='#FF0000'>as</font><font color='#000000'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></strong></em></big></big></big><input src='../multico.jpg' name='I1' alt='Falta el logo' type='image'></p><div align='center'><center>\n");

print("<script language='JavaScript'> function NuevaConsulta(){ location.href='consulta.php'; } </script>");

/* Cargar los arrays de campos */
  $descriptor	= odbc_connect("SOPORTE","","");
  $query	= "select * from CAMPOS";
  $registro	= odbc_exec($descriptor, $query);
  $i=0;
  $CNom[$i]=""; /* CAMPOS.Campo */
  $CDesc[$i]="";/* CAMPOS.Descripci�n*/
  while (odbc_fetch_row($registro)) {
	$CNom[$i] = odbc_result($registro, 2); /* ($registro, "CAMPO") */
	$CDesc[$i] = odbc_result($registro, 3);/* ($registro, "DESCRIPCION") */
        $i++;
  }
/* Inicio del formulario */
printf("<form name='formularioAltas' method='post' action='actualizar.php'>\n");

print("<table border='0' width='100%' height='189'>\n"); 
print("<tr>\n");

$queryC�digo	= "select * from PROBLEMAS WHERE  ID LIKE '$C�DIGO'";
$registroC�digo	= odbc_exec($descriptor, $queryC�digo);
//echo($queryC�digo);

$c�digo = odbc_result($registroC�digo, 1);
print("<td width='15%' align='left' valign='baseline' height='25'> <p>ID: </p>\n");
print("</td>\n");
print("<td width='35%' align='left' valign='baseline' height='25'><input type='button' name='ID' size='22' value = '$c�digo'><input type='hidden' name='ID' size='22' value = '$c�digo'>
</td>\n");
/***************************** Campos de fecha *************************************/
$finicio = odbc_result($registroC�digo, 11);
print("<td align='left' valign='baseline'> <p>Fecha inicio: </p>\n");
print("</td>\n");
print("<td width='35%' align='left' valign='baseline' height='25'><input type='text' name='FINICIO' size='22' value = '$finicio'></td>\n");
print("</tr>\n");

$fultimo = odbc_result($registroC�digo, 12);
print("<tr>\n");
print("<td ></td>");
print("<td ></td>");
print("<td width='15%' align='left' valign='baseline' height='25'> <p>�ltimo: </p>\n");
print("</td>\n");
print("<td width='35%' align='left' valign='baseline' height='25'><input type='text' name='ULTIMO' size='22' value = '$fultimo'></td>\n");
/********************************************************************************/

print("</tr>\n");

print("<tr>\n");
print("<td width='15%' align='left' valign='baseline' height='26'><p>Empresa:</p>\n");
print("</td>\n");
$empresa = odbc_result($registroC�digo, 6);
print("<td width='35%' align='left' valign='baseline' height='26'><input type='text' name='EMPRESA' size='35' tabindex='1' value = '$empresa'></td>\n");

print("<td width='15%' align='left' valign='baseline' height='26'><p>T�cnico:</p>\n");
print("</td>\n");
$t�cnico = odbc_result($registroC�digo, 10);
print("<td width='35%' align='left' valign='baseline' height='26'><input type='text' name='T�CNICO' size='22' tabindex='1' value = '$t�cnico'></td>\n");

print("<tr>\n");
print("<td width='15%' valign='middle' height='26' align='left'><p>Contacto:&nbsp;&nbsp; </p>\n");
print("</td>\n");
$contacto = odbc_result($registroC�digo, 7);
print("<td width='35%' valign='middle' height='26' align='left'><input type='text' name='CONTACTO' size='22' tabindex='2' value = '$contacto'></td>\n");

print("<td width='15%' valign='middle' height='26' align='left'><p>Prioridad:&nbsp;&nbsp; </p>\n");
print("</td>\n");
$prioridad = odbc_result($registroC�digo, 5);
print("<td width='35%' valign='middle' height='26' align='left'><input type='text' name='PRIORIDAD' size='22' tabindex='2' value = '$prioridad'></td>\n");
print("</tr>\n");

print("<tr>\n");
print("<td width='15%' align='left' valign='middle' height='26'>Tel�fono:</td>\n");
$tel�fono = odbc_result($registroC�digo, 8);
print("<td width='35%' align='left' valign='middle' height='26'><p><input type='text' name='TEL�FONO' size='22' tabindex='3' value = '$tel�fono'></p>\n");

print("<td width='11%' align='left' valign='top' height='26'>Comentarios:</td>\n");
$comentarios = odbc_result($registroC�digo, 9);
print("<td width='35%' align='left' valign='baseline' height='26'><textarea rows='3' name='COMENTARIOS' cols='33' tabindex='6'>$comentarios</textarea></td>\n");
print("</tr>\n");

print("<tr>\n");
print("<td width='15%' align='left' valign='baseline' height='26'><p>Producto:&nbsp;&nbsp;</p>\n");
print("</td>\n");
$producto = odbc_result($registroC�digo, 2);
print("<td width='35%' align='left' valign='baseline' height='26'><input type='text' name='PRODUCTO' size='22' tabindex='4' value = '$producto'></td>\n");
print("<td width='6%' align='left' valign='baseline' height='26'></td>\n");
print("<td width='22%' align='left' valign='baseline' height='26' colspan='2'></td>\n");
print("<td width='22%' align='left' valign='baseline' height='26'></td>\n");
print("</tr>\n");
print("<tr>\n");
print("<td width='15%' align='left' valign='top' height='86'><p>Problema:&nbsp;&nbsp;</p>\n");
print("</td>\n");
$problema = odbc_result($registroC�digo, 3);
print("<td width='35%' align='left' valign='top' height='86'><textarea rows='3' name='PROBLEMA' cols='27' tabindex='5'>$problema</textarea></td>\n");

print("<td width='6%' align='left' valign='top' height='86'>Soluci�n:</td>\n");
$soluci�n = odbc_result($registroC�digo, 4);
print("<td width='44%' align='left' valign='top' height='86' colspan='3'><p><textarea rows='3' name='SOLUCI�N' cols='33' tabindex='10'>$soluci�n</textarea></p>\n");
print("</td>\n");
print("</tr>\n");

/* Botones de env�o */
printf("	<tr><td><input type='Submit' name='CONSULTAR' value='Actualizar'></td><td><input type='Reset'><td><Input type=button value='Nueva Consulta' onClick=NuevaConsulta();></td></tr>\n");
print("</table>\n");
printf("</form>\n");
print("</center></div>\n");


/* Cerrar la base de datos*/
odbc_close($descriptor);
print("</body>\n");
print("</html>\n");
?>
